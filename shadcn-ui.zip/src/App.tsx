import { useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from '@/components/providers/ThemeProvider';
import { Header } from '@/components/layout/Header';
import { Hero } from '@/components/sections/Hero';
import { Gallery } from '@/components/sections/Gallery';
import { Technologies } from '@/components/sections/Technologies';
import { VideoSection } from '@/components/sections/VideoSection';
import { Categories } from '@/components/sections/Categories';
import { Products } from '@/components/sections/Products';
import { Footer } from '@/components/layout/Footer';
import { ThreeBackground } from '@/components/3d/ThreeBackground';
import { OrderPage } from '@/pages/Order';

const queryClient = new QueryClient();

const App = () => {
  const [currentView, setCurrentView] = useState<'home' | 'shop' | 'order'>('home');

  return (
    <ThemeProvider defaultTheme="light" storageKey="3dbishkek-theme">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <div className="min-h-screen">
          {currentView === 'home' ? (
            // Home Page
            <>
              <Header currentView={currentView} onViewChange={setCurrentView} />
              <main>
                <Hero onViewChange={setCurrentView} />
                <Gallery />
                <Technologies />
                <VideoSection />
              </main>
              <Footer />
            </>
          ) : currentView === 'shop' ? (
            // Shop Page
            <>
              {/* Header Section with 3D Background */}
              <div className="relative min-h-[400px] overflow-hidden">
                <ThreeBackground />
                <Header currentView={currentView} onViewChange={setCurrentView} />
                <div className="pt-20 relative z-10">
                  <Categories />
                </div>
              </div>
              
              {/* Products Section with Regular Background */}
              <div className="bg-gray-50 min-h-screen">
                <main className="relative z-10">
                  <Products />
                </main>
                <Footer />
              </div>
            </>
          ) : (
            // Order Page
            <OrderPage onViewChange={setCurrentView} />
          )}
        </div>
      </TooltipProvider>
    </QueryClientProvider>
    </ThemeProvider>
  );
};

export default App;