export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  badge?: 'new' | 'hit' | 'sale';
  image?: string;
  inStock: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export type CategoryFilter = 'all' | 'home' | 'games' | 'jewelry' | 'tools' | 'robotics';

export interface Order3D {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  description: string;
  quantity: number;
  material?: string;
  color?: string;
  size?: string;
  specialRequirements?: string;
  deliveryMethod?: 'pickup' | 'delivery';
  deliveryAddress?: string;
  files: FileInfo[];
  status: 'draft' | 'confirmed' | 'sent';
  createdAt: Date;
}

export interface FileInfo {
  id: string;
  name: string;
  size: number;
  type: string;
  path: string;
  uploadedAt: Date;
}

export interface OrderFormData {
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  description?: string;
  quantity?: number;
  material?: string;
  color?: string;
  size?: string;
  specialRequirements?: string;
  deliveryMethod?: 'pickup' | 'delivery';
  deliveryAddress?: string;
}