import { Order3D, OrderFormData, FileInfo } from '@/types';

export class OrderManager {
  private currentOrder: Partial<Order3D> | null = null;
  private conversationStep = 0;
  private isInOrderMode = false;

  private readonly orderSteps = [
    'greeting',
    'customer_info',
    'order_description',
    'quantity',
    'material',
    'color',
    'size',
    'special_requirements',
    'delivery',
    'confirmation'
  ];

  startOrder(): string {
    this.isInOrderMode = true;
    this.conversationStep = 0;
    this.currentOrder = {
      id: Date.now().toString(),
      files: [],
      status: 'draft',
      createdAt: new Date(),
    };

    return `Отлично! Давайте оформим заказ на 3D печать. 

Для начала мне нужно узнать вашу контактную информацию:
- Как вас зовут?
- Ваш номер телефона?
- Email для связи?`;
  }

  processMessage(message: string): string {
    if (!this.isInOrderMode || !this.currentOrder) {
      return this.checkForOrderIntent(message);
    }

    const step = this.orderSteps[this.conversationStep];

    switch (step) {
      case 'greeting':
        return this.handleGreeting(message);
      case 'customer_info':
        return this.handleCustomerInfo(message);
      case 'order_description':
        return this.handleOrderDescription(message);
      case 'quantity':
        return this.handleQuantity(message);
      case 'material':
        return this.handleMaterial(message);
      case 'color':
        return this.handleColor(message);
      case 'size':
        return this.handleSize(message);
      case 'special_requirements':
        return this.handleSpecialRequirements(message);
      case 'delivery':
        return this.handleDelivery(message);
      case 'confirmation':
        return this.handleConfirmation(message);
      default:
        return 'Извините, произошла ошибка. Попробуйте начать заказ заново.';
    }
  }

  private checkForOrderIntent(message: string): string {
    const orderKeywords = [
      'заказ', 'заказать', 'хочу заказать', 'нужен заказ',
      '3d печать', 'напечатать', 'изготовить', 'сделать',
      'цена', 'стоимость', 'сколько стоит'
    ];

    const lowerMessage = message.toLowerCase();
    const hasOrderIntent = orderKeywords.some(keyword => lowerMessage.includes(keyword));

    if (hasOrderIntent) {
      return this.startOrder();
    }

    return '';
  }

  private handleGreeting(message: string): string {
    // This step is just for transition
    this.conversationStep++;
    return `Спасибо! Теперь расскажите, что именно вы хотите напечатать? 
Опишите детально ваш проект или изделие.`;
  }

  private handleCustomerInfo(message: string): string {
    // Extract customer info from message
    const nameMatch = message.match(/(?:зовут|имя|я)\s+([А-Яа-яЁё\s]+)/i);
    const phoneMatch = message.match(/(\+996\d{9}|\d{9,12})/);
    const emailMatch = message.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);

    if (nameMatch) this.currentOrder!.customerName = nameMatch[1].trim();
    if (phoneMatch) this.currentOrder!.customerPhone = phoneMatch[1];
    if (emailMatch) this.currentOrder!.customerEmail = emailMatch[1];

    if (this.currentOrder!.customerName && this.currentOrder!.customerPhone && this.currentOrder!.customerEmail) {
      this.conversationStep++;
      return `Отлично! Ваши контактные данные сохранены.

Теперь расскажите подробнее о вашем заказе. Что именно нужно напечатать?`;
    } else {
      const missing = [];
      if (!this.currentOrder!.customerName) missing.push('имя');
      if (!this.currentOrder!.customerPhone) missing.push('телефон');
      if (!this.currentOrder!.customerEmail) missing.push('email');

      return `Мне не удалось распознать ${missing.join(', ')}. 
Пожалуйста, укажите:
${!this.currentOrder!.customerName ? '- Ваше имя' : ''}
${!this.currentOrder!.customerPhone ? '- Номер телефона (в формате +996XXXXXXXXX)' : ''}
${!this.currentOrder!.customerEmail ? '- Email адрес' : ''}`;
    }
  }

  private handleOrderDescription(message: string): string {
    this.currentOrder!.description = message;
    this.conversationStep++;
    return 'Хорошо! Сколько экземпляров вам нужно?';
  }

  private handleQuantity(message: string): string {
    const quantityMatch = message.match(/(\d+)/);
    if (quantityMatch) {
      this.currentOrder!.quantity = parseInt(quantityMatch[1]);
      this.conversationStep++;
      return 'Какой материал вы предпочитаете? (PLA, ABS, PETG, Nylon, или укажите другой)';
    } else {
      return 'Пожалуйста, укажите количество цифрами (например: 1, 5, 10)';
    }
  }

  private handleMaterial(message: string): string {
    this.currentOrder!.material = message;
    this.conversationStep++;
    return 'Хотите указать цвет? (Если нет, напишите "любой" или "стандартный")';
  }

  private handleColor(message: string): string {
    if (message.toLowerCase().includes('люб') || message.toLowerCase().includes('стандарт')) {
      this.currentOrder!.color = 'стандартный';
    } else {
      this.currentOrder!.color = message;
    }
    this.conversationStep++;
    return 'Укажите примерные размеры изделия (длина × ширина × высота в мм, или "по файлу")';
  }

  private handleSize(message: string): string {
    this.currentOrder!.size = message;
    this.conversationStep++;
    return 'Есть ли особые требования или пожелания к печати? (Если нет, напишите "нет")';
  }

  private handleSpecialRequirements(message: string): string {
    if (!message.toLowerCase().includes('нет')) {
      this.currentOrder!.specialRequirements = message;
    }
    this.conversationStep++;
    return 'Как вы хотите получить заказ? (самовывоз или доставка по адресу)';
  }

  private handleDelivery(message: string): string {
    if (message.toLowerCase().includes('самовывоз') || message.toLowerCase().includes('забрать')) {
      this.currentOrder!.deliveryMethod = 'pickup';
    } else if (message.toLowerCase().includes('доставк')) {
      this.currentOrder!.deliveryMethod = 'delivery';
      return 'Укажите адрес доставки:';
    } else {
      return 'Пожалуйста, выберите: "самовывоз" или "доставка"';
    }

    this.conversationStep++;
    return this.generateOrderSummary();
  }

  private generateOrderSummary(): string {
    const order = this.currentOrder!;
    return `Отлично! Вот ваш заказ:

👤 Клиент: ${order.customerName}
📞 Телефон: ${order.customerPhone}
📧 Email: ${order.customerEmail}

📦 Заказ: ${order.description}
🔢 Количество: ${order.quantity}
🧵 Материал: ${order.material}
🎨 Цвет: ${order.color}
📏 Размеры: ${order.size}
${order.specialRequirements ? `📝 Особые требования: ${order.specialRequirements}` : ''}
🚚 Доставка: ${order.deliveryMethod === 'pickup' ? 'Самовывоз' : 'Доставка'}
${order.deliveryAddress ? `📍 Адрес: ${order.deliveryAddress}` : ''}

Все правильно? Напишите "да" для подтверждения или "изменить" для корректировки.`;
  }

  private handleConfirmation(message: string): string {
    if (message.toLowerCase().includes('да') || message.toLowerCase().includes('подтверд')) {
      this.currentOrder!.status = 'confirmed';
      this.isInOrderMode = false;
      return `✅ Заказ подтвержден! 

Мы свяжемся с вами в ближайшее время для уточнения деталей и отправим расчет стоимости.
Ваш заказ будет обработан в течение 1-2 рабочих дней.

Спасибо за заказ!`;
    } else if (message.toLowerCase().includes('изменить') || message.toLowerCase().includes('исправить')) {
      this.conversationStep = 1; // Go back to customer info
      return 'Хорошо, давайте исправим информацию. С чего начнем?';
    } else {
      return 'Пожалуйста, напишите "да" для подтверждения или "изменить" для корректировки.';
    }
  }

  getCurrentOrder(): Partial<Order3D> | null {
    return this.currentOrder;
  }

  addFiles(files: FileInfo[]): void {
    if (this.currentOrder) {
      this.currentOrder.files = [...(this.currentOrder.files || []), ...files];
    }
  }

  isOrderInProgress(): boolean {
    return this.isInOrderMode;
  }

  resetOrder(): void {
    this.currentOrder = null;
    this.conversationStep = 0;
    this.isInOrderMode = false;
  }
}