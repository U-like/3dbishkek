import { Order3D } from '@/types';

// Type declaration for EmailJS
declare global {
  interface Window {
    EmailJS?: {
      send: (serviceId: string, templateId: string, data: Record<string, unknown>) => Promise<unknown>;
    };
  }
}

interface EmailConfig {
  smtpHost: string;
  smtpPort: number;
  smtpUser: string;
  smtpPass: string;
  fromEmail: string;
  toEmail: string;
}

const EMAIL_CONFIG: EmailConfig = {
  smtpHost: 'mail.3dbishkek.kg',
  smtpPort: 465,
  smtpUser: 'manager@3dbishkek.kg',
  smtpPass: '', // This should be set securely
  fromEmail: 'manager@3dbishkek.kg',
  toEmail: 'ulikebot@gmail.com',
};

export async function sendOrderEmail(order: Order3D): Promise<boolean> {
  try {
    // Create email content
    const subject = `Новый заказ 3D печати #${order.id}`;
    const body = createOrderEmailBody(order);

    // For now, we'll use a simple approach
    // In production, you'd use a proper email service or SMTP library
    const emailData = {
      to: EMAIL_CONFIG.toEmail,
      from: EMAIL_CONFIG.fromEmail,
      subject,
      body,
      attachments: order.files.map(file => ({
        filename: file.name,
        content: localStorage.getItem(`file_${file.id}`)?.split(',')[1], // Remove data URL prefix
        encoding: 'base64',
      })),
    };

    // Simulate email sending (replace with actual email service)
    console.log('Sending email:', emailData);

    // You would typically use a service like:
    // - EmailJS
    // - SendGrid
    // - AWS SES
    // - Or a backend API endpoint

    // For demonstration, we'll use EmailJS if available
    if (window.EmailJS) {
      await window.EmailJS.send(
        'service_id', // Replace with your service ID
        'template_id', // Replace with your template ID
        {
          to_email: EMAIL_CONFIG.toEmail,
          from_email: EMAIL_CONFIG.fromEmail,
          subject,
          message: body,
          order_id: order.id,
        }
      );
    } else {
      // Fallback: create mailto link
      const mailtoLink = `mailto:${EMAIL_CONFIG.toEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.open(mailtoLink);
    }

    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}

function createOrderEmailBody(order: Order3D): string {
  return `
Новый заказ 3D печати

ID заказа: ${order.id}
Дата создания: ${order.createdAt.toLocaleString('ru-RU')}

Информация о клиенте:
- Имя: ${order.customerName}
- Телефон: ${order.customerPhone}
- Email: ${order.customerEmail}

Детали заказа:
- Описание: ${order.description}
- Количество: ${order.quantity}
${order.material ? `- Материал: ${order.material}` : ''}
${order.color ? `- Цвет: ${order.color}` : ''}
${order.size ? `- Размер: ${order.size}` : ''}
${order.specialRequirements ? `- Особые требования: ${order.specialRequirements}` : ''}

Доставка:
- Способ: ${order.deliveryMethod === 'pickup' ? 'Самовывоз' : 'Доставка'}
${order.deliveryAddress ? `- Адрес: ${order.deliveryAddress}` : ''}

Прикрепленные файлы: ${order.files.length}
${order.files.map(f => `- ${f.name} (${(f.size / 1024 / 1024).toFixed(2)}MB)`).join('\n')}

Статус: ${order.status === 'confirmed' ? 'Подтвержден' : 'Черновик'}
  `.trim();
}

// Utility to get file content for email attachments
export function getFileContent(fileId: string): string | null {
  const dataUrl = localStorage.getItem(`file_${fileId}`);
  if (!dataUrl) return null;

  // Remove the data URL prefix (e.g., "data:application/octet-stream;base64,")
  const base64Data = dataUrl.split(',')[1];
  return base64Data;
}