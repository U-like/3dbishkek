import DatingApp from '@/components/DatingApp'

export default function Home() {
  return <DatingApp />
}