import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { findCompatibleMatches } from '@/lib/matching'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const status = searchParams.get('status') // 'PENDING', 'ACCEPTED', 'REJECTED'

    if (userId) {
      // Get matches for a user
      const whereClause: any = {
        OR: [
          { senderId: userId },
          { receiverId: userId }
        ]
      }

      if (status) {
        whereClause.status = status
      }

      const matches = await db.match.findMany({
        where: whereClause,
        include: {
          sender: {
            include: {
              interests: {
                include: {
                  interest: true
                }
              }
            }
          },
          receiver: {
            include: {
              interests: {
                include: {
                  interest: true
                }
              }
            }
          },
          chat: true
        },
        orderBy: {
          createdAt: 'desc'
        }
      })

      return NextResponse.json({ matches })
    } else {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }
  } catch (error) {
    console.error('Error fetching matches:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { senderId, receiverId } = body

    if (!senderId || !receiverId) {
      return NextResponse.json({ error: 'senderId and receiverId are required' }, { status: 400 })
    }

    if (senderId === receiverId) {
      return NextResponse.json({ error: 'Cannot create match with yourself' }, { status: 400 })
    }

    // Check if match already exists
    const existingMatch = await db.match.findFirst({
      where: {
        OR: [
          { senderId, receiverId },
          { senderId: receiverId, receiverId: senderId }
        ]
      }
    })

    if (existingMatch) {
      return NextResponse.json({ error: 'Match already exists' }, { status: 400 })
    }

    // Get both users with their interests
    const [sender, receiver] = await Promise.all([
      db.user.findUnique({
        where: { id: senderId },
        include: {
          interests: {
            include: {
              interest: true
            }
          }
        }
      }),
      db.user.findUnique({
        where: { id: receiverId },
        include: {
          interests: {
            include: {
              interest: true
            }
          }
        }
      })
    ])

    if (!sender || !receiver) {
      return NextResponse.json({ error: 'One or both users not found' }, { status: 404 })
    }

    // Calculate compatibility
    const compatibility = findCompatibleMatches(sender, [receiver], 1)
    const compatibilityScore = compatibility.length > 0 ? compatibility[0].compatibility.score : 50

    // Create match
    const match = await db.match.create({
      data: {
        senderId,
        receiverId,
        compatibility: compatibilityScore
      },
      include: {
        sender: {
          include: {
            interests: {
              include: {
                interest: true
              }
            }
          }
        },
        receiver: {
          include: {
            interests: {
              include: {
                interest: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json({ match }, { status: 201 })
  } catch (error) {
    console.error('Error creating match:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, status, chatId } = body

    if (!matchId || !status) {
      return NextResponse.json({ error: 'matchId and status are required' }, { status: 400 })
    }

    if (!['PENDING', 'ACCEPTED', 'REJECTED'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    }

    // Update match
    const match = await db.match.update({
      where: { id: matchId },
      data: { status },
      include: {
        sender: {
          include: {
            interests: {
              include: {
                interest: true
              }
            }
          }
        },
        receiver: {
          include: {
            interests: {
              include: {
                interest: true
              }
            }
          }
        },
        chat: true
      }
    })

    // If match is accepted and no chat exists, create one
    if (status === 'ACCEPTED' && !match.chat) {
      const chat = await db.chat.create({
        data: {
          matchId: match.id,
          participants: {
            connect: [
              { id: match.senderId },
              { id: match.receiverId }
            ]
          }
        },
        include: {
          participants: true,
          match: true
        }
      })

      // Update match with chat ID
      await db.match.update({
        where: { id: matchId },
        data: { chatId: chat.id }
      })

      match.chat = chat
    }

    return NextResponse.json({ match })
  } catch (error) {
    console.error('Error updating match:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}