import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const chatId = searchParams.get('chatId')

    if (chatId) {
      // Get specific chat
      const chat = await db.chat.findUnique({
        where: { id: chatId },
        include: {
          participants: true,
          messages: {
            orderBy: {
              createdAt: 'asc'
            },
            include: {
              sender: {
                select: {
                  id: true,
                  name: true,
                  avatar: true,
                  avatarBlur: true
                }
              }
            }
          },
          match: {
            include: {
              sender: true,
              receiver: true
            }
          }
        }
      })

      if (!chat) {
        return NextResponse.json({ error: 'Chat not found' }, { status: 404 })
      }

      return NextResponse.json({ chat })
    } else if (userId) {
      // Get all chats for a user
      const chats = await db.chat.findMany({
        where: {
          participants: {
            some: {
              id: userId
            }
          }
        },
        include: {
          participants: {
            where: {
              id: {
                not: userId
              }
            },
            select: {
              id: true,
              name: true,
              avatar: true,
              avatarBlur: true,
              isOnline: true,
              lastSeen: true
            }
          },
          messages: {
            orderBy: {
              createdAt: 'desc'
            },
            take: 1,
            include: {
              sender: {
                select: {
                  id: true,
                  name: true
                }
              }
            }
          },
          match: {
            include: {
              sender: true,
              receiver: true
            }
          }
        },
        orderBy: {
          updatedAt: 'desc'
        }
      })

      return NextResponse.json({ chats })
    } else {
      return NextResponse.json({ error: 'userId or chatId is required' }, { status: 400 })
    }
  } catch (error) {
    console.error('Error fetching chats:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { participantIds, name, matchId } = body

    if (!participantIds || participantIds.length < 2) {
      return NextResponse.json({ error: 'At least 2 participants are required' }, { status: 400 })
    }

    // Create chat
    const chat = await db.chat.create({
      data: {
        name,
        matchId,
        participants: {
          connect: participantIds.map((id: string) => ({ id }))
        }
      },
      include: {
        participants: true,
        match: true
      }
    })

    return NextResponse.json({ chat }, { status: 201 })
  } catch (error) {
    console.error('Error creating chat:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}