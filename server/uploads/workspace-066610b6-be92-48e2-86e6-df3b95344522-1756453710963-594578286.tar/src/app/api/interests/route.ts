import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getInterestSuggestions } from '@/lib/matching'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const category = searchParams.get('category')
    const limit = parseInt(searchParams.get('limit') || '50')

    if (userId) {
      // Get interests for a specific user
      const userInterests = await db.userInterest.findMany({
        where: { userId },
        include: {
          interest: true
        }
      })

      return NextResponse.json({ interests: userInterests })
    } else {
      // Get all interests with filtering
      const whereClause: any = {}
      if (category) {
        whereClause.category = category
      }

      const interests = await db.interest.findMany({
        where: whereClause,
        include: {
          users: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true
                }
              }
            }
          }
        },
        take: limit,
        orderBy: {
          name: 'asc'
        }
      })

      return NextResponse.json({ interests })
    }
  } catch (error) {
    console.error('Error fetching interests:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, category, userId, level } = body

    if (!name) {
      return NextResponse.json({ error: 'name is required' }, { status: 400 })
    }

    // Create or find interest
    const interest = await db.interest.upsert({
      where: { name },
      update: category ? { category } : {},
      create: {
        name,
        category: category || 'other'
      }
    })

    // If userId is provided, add user interest
    if (userId) {
      // Check if user already has this interest
      const existingUserInterest = await db.userInterest.findUnique({
        where: {
          userId_interestId: {
            userId,
            interestId: interest.id
          }
        }
      })

      if (existingUserInterest) {
        // Update existing user interest
        const updatedUserInterest = await db.userInterest.update({
          where: { id: existingUserInterest.id },
          data: { level: level || existingUserInterest.level },
          include: {
            interest: true
          }
        })

        return NextResponse.json({ userInterest: updatedUserInterest })
      } else {
        // Create new user interest
        const userInterest = await db.userInterest.create({
          data: {
            userId,
            interestId: interest.id,
            level: level || 1
          },
          include: {
            interest: true
          }
        })

        return NextResponse.json({ userInterest }, { status: 201 })
      }
    }

    return NextResponse.json({ interest }, { status: 201 })
  } catch (error) {
    console.error('Error creating interest:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const interestId = searchParams.get('interestId')

    if (!userId || !interestId) {
      return NextResponse.json({ error: 'userId and interestId are required' }, { status: 400 })
    }

    // Delete user interest
    const deletedUserInterest = await db.userInterest.deleteMany({
      where: {
        userId,
        interestId
      }
    })

    if (deletedUserInterest.count === 0) {
      return NextResponse.json({ error: 'User interest not found' }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting user interest:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}