import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const chatId = searchParams.get('chatId')
    const userId = searchParams.get('userId')

    if (chatId) {
      // Get messages for a specific chat
      const messages = await db.message.findMany({
        where: { chatId },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              avatar: true,
              avatarBlur: true
            }
          }
        },
        orderBy: {
          createdAt: 'asc'
        }
      })

      return NextResponse.json({ messages })
    } else if (userId) {
      // Get all messages for a user
      const messages = await db.message.findMany({
        where: {
          OR: [
            { senderId: userId },
            { chat: { participants: { some: { id: userId } } } }
          ]
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              avatar: true,
              avatarBlur: true
            }
          },
          chat: {
            select: {
              id: true,
              name: true,
              participants: {
                where: {
                  id: {
                    not: userId
                  }
                },
                select: {
                  id: true,
                  name: true
                }
              }
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      })

      return NextResponse.json({ messages })
    } else {
      return NextResponse.json({ error: 'chatId or userId is required' }, { status: 400 })
    }
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { chatId, content, senderId } = body

    if (!chatId || !content || !senderId) {
      return NextResponse.json({ error: 'chatId, content, and senderId are required' }, { status: 400 })
    }

    // Verify user is participant in the chat
    const chat = await db.chat.findUnique({
      where: { id: chatId },
      include: {
        participants: true
      }
    })

    if (!chat) {
      return NextResponse.json({ error: 'Chat not found' }, { status: 404 })
    }

    const isParticipant = chat.participants.some(p => p.id === senderId)
    if (!isParticipant) {
      return NextResponse.json({ error: 'User is not a participant in this chat' }, { status: 403 })
    }

    // Create message
    const message = await db.message.create({
      data: {
        chatId,
        content,
        senderId
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            avatar: true,
            avatarBlur: true
          }
        }
      }
    })

    // Update chat activity
    const currentWeek = getCurrentWeekNumber()
    const existingActivity = await db.chatActivity.findUnique({
      where: {
        chatId_userId_weekNumber: {
          chatId,
          userId: senderId,
          weekNumber: currentWeek
        }
      }
    })

    if (existingActivity) {
      await db.chatActivity.update({
        where: { id: existingActivity.id },
        data: {
          messageCount: existingActivity.messageCount + 1,
          intensityScore: Math.min(100, existingActivity.intensityScore + Math.min(10, content.length / 10))
        }
      })
    } else {
      await db.chatActivity.create({
        data: {
          chatId,
          userId: senderId,
          weekNumber: currentWeek,
          messageCount: 1,
          intensityScore: Math.min(10, content.length / 10)
        }
      })
    }

    // Update chat's last updated time
    await db.chat.update({
      where: { id: chatId },
      data: { updatedAt: new Date() }
    })

    return NextResponse.json({ message }, { status: 201 })
  } catch (error) {
    console.error('Error creating message:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { messageId, userId } = body

    if (!messageId || !userId) {
      return NextResponse.json({ error: 'messageId and userId are required' }, { status: 400 })
    }

    // Mark message as read
    const message = await db.message.update({
      where: { id: messageId },
      data: { read: true },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            avatar: true,
            avatarBlur: true
          }
        }
      }
    })

    return NextResponse.json({ message })
  } catch (error) {
    console.error('Error updating message:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

function getCurrentWeekNumber() {
  const now = new Date()
  const startOfYear = new Date(now.getFullYear(), 0, 1)
  const pastDaysOfYear = (now.getTime() - startOfYear.getTime()) / 86400000
  return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7)
}