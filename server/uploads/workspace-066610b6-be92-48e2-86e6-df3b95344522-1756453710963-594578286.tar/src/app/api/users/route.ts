import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { calculateCompatibility, findCompatibleMatches } from '@/lib/matching'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = parseInt(searchParams.get('limit') || '10')
    const sortBy = searchParams.get('sortBy') || 'compatibility'

    if (userId) {
      // Get specific user
      const user = await db.user.findUnique({
        where: { id: userId },
        include: {
          interests: {
            include: {
              interest: true
            }
          },
          sentMatches: {
            include: {
              receiver: true
            }
          },
          receivedMatches: {
            include: {
              sender: true
            }
          }
        }
      })

      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 })
      }

      return NextResponse.json({ user })
    } else {
      // Get all users with their interests
      const users = await db.user.findMany({
        include: {
          interests: {
            include: {
              interest: true
            }
          }
        }
      })

      // If sortBy is compatibility, we need a target user
      if (sortBy === 'compatibility') {
        const targetUserId = searchParams.get('targetUserId')
        if (targetUserId) {
          const targetUser = users.find(u => u.id === targetUserId)
          if (targetUser) {
            const matches = findCompatibleMatches(targetUser, users, limit)
            return NextResponse.json({ users: matches })
          }
        }
      }

      // Apply other sorting
      let sortedUsers = users
      if (sortBy === 'newest') {
        sortedUsers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      } else if (sortBy === 'online') {
        sortedUsers.sort((a, b) => {
          if (a.isOnline && !b.isOnline) return -1
          if (!a.isOnline && b.isOnline) return 1
          return 0
        })
      }

      return NextResponse.json({ users: sortedUsers.slice(0, limit) })
    }
  } catch (error) {
    console.error('Error fetching users:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, name, bio, gender, lookingFor, age, location, interests } = body

    // Create user
    const user = await db.user.create({
      data: {
        email,
        name,
        bio,
        gender,
        lookingFor,
        age,
        location
      }
    })

    // Add interests if provided
    if (interests && interests.length > 0) {
      for (const interestData of interests) {
        // Find or create interest
        const interest = await db.interest.upsert({
          where: { name: interestData.name },
          update: {},
          create: {
            name: interestData.name,
            category: interestData.category || 'other'
          }
        })

        // Add user interest
        await db.userInterest.create({
          data: {
            userId: user.id,
            interestId: interest.id,
            level: interestData.level || 1
          }
        })
      }
    }

    // Fetch the created user with interests
    const createdUser = await db.user.findUnique({
      where: { id: user.id },
      include: {
        interests: {
          include: {
            interest: true
          }
        }
      }
    })

    return NextResponse.json({ user: createdUser }, { status: 201 })
  } catch (error) {
    console.error('Error creating user:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}