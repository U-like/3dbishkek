import { Server } from 'socket.io';

interface UserSocket {
  userId: string;
  socketId: string;
}

interface ChatMessage {
  id: string;
  chatId: string;
  content: string;
  senderId: string;
  timestamp: string;
}

interface ChatActivity {
  chatId: string;
  userId: string;
  messageCount: number;
  intensityScore: number;
}

// Store online users
const onlineUsers = new Map<string, string>(); // userId -> socketId

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // User joins with their userId
    socket.on('user:join', (data: { userId: string }) => {
      const { userId } = data;
      
      // Store user as online
      onlineUsers.set(userId, socket.id);
      socket.userId = userId;
      
      // Join user to their personal room
      socket.join(`user:${userId}`);
      
      // Broadcast user online status
      socket.broadcast.emit('user:online', { userId });
      
      console.log(`User ${userId} joined with socket ${socket.id}`);
    });

    // Handle joining a chat room
    socket.on('chat:join', (data: { chatId: string }) => {
      const { chatId } = data;
      socket.join(`chat:${chatId}`);
      console.log(`User ${socket.userId} joined chat ${chatId}`);
    });

    // Handle leaving a chat room
    socket.on('chat:leave', (data: { chatId: string }) => {
      const { chatId } = data;
      socket.leave(`chat:${chatId}`);
      console.log(`User ${socket.userId} left chat ${chatId}`);
    });

    // Handle sending messages
    socket.on('message:send', async (data: ChatMessage) => {
      try {
        const { chatId, content, senderId } = data;
        
        // Create message object
        const message: ChatMessage = {
          id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          chatId,
          content,
          senderId,
          timestamp: new Date().toISOString()
        };

        // Broadcast message to all users in the chat room
        io.to(`chat:${chatId}`).emit('message:new', message);
        
        // Update chat activity
        const activityUpdate: ChatActivity = {
          chatId,
          userId: senderId,
          messageCount: 1,
          intensityScore: Math.min(10, content.length / 10) // Simple scoring based on message length
        };
        
        // Emit activity update
        io.to(`chat:${chatId}`).emit('chat:activity', activityUpdate);
        
        console.log(`Message sent in chat ${chatId} by user ${senderId}`);
      } catch (error) {
        console.error('Error sending message:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Handle typing indicators
    socket.on('typing:start', (data: { chatId: string; userId: string }) => {
      socket.to(`chat:${data.chatId}`).emit('typing:start', {
        userId: data.userId,
        chatId: data.chatId
      });
    });

    socket.on('typing:stop', (data: { chatId: string; userId: string }) => {
      socket.to(`chat:${data.chatId}`).emit('typing:stop', {
        userId: data.userId,
        chatId: data.chatId
      });
    });

    // Handle message read receipts
    socket.on('message:read', (data: { messageId: string; userId: string }) => {
      const { messageId, userId } = data;
      socket.broadcast.emit('message:read', { messageId, userId });
    });

    // Handle match requests
    socket.on('match:request', (data: { senderId: string; receiverId: string }) => {
      const { senderId, receiverId } = data;
      
      // Check if receiver is online
      const receiverSocketId = onlineUsers.get(receiverId);
      if (receiverSocketId) {
        io.to(receiverSocketId).emit('match:request', { senderId });
      }
      
      console.log(`Match request from ${senderId} to ${receiverId}`);
    });

    // Handle match responses
    socket.on('match:response', (data: { 
      senderId: string; 
      receiverId: string; 
      accepted: boolean;
      chatId?: string 
    }) => {
      const { senderId, receiverId, accepted, chatId } = data;
      
      // Notify the original sender
      const senderSocketId = onlineUsers.get(senderId);
      if (senderSocketId) {
        io.to(senderSocketId).emit('match:response', { 
          receiverId, 
          accepted,
          chatId 
        });
      }
      
      console.log(`Match response from ${receiverId} to ${senderId}: ${accepted}`);
    });

    // Handle getting online users
    socket.on('users:online', () => {
      const onlineUserIds = Array.from(onlineUsers.keys());
      socket.emit('users:online', onlineUserIds);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      if (socket.userId) {
        // Remove user from online users
        onlineUsers.delete(socket.userId);
        
        // Broadcast user offline status
        socket.broadcast.emit('user:offline', { userId: socket.userId });
        
        console.log(`User ${socket.userId} disconnected`);
      }
      
      console.log('Client disconnected:', socket.id);
    });

    // Send welcome message
    socket.emit('connected', {
      message: 'Welcome to the Dating App WebSocket!',
      timestamp: new Date().toISOString()
    });
  });
};

// Extend Socket interface to include custom properties
declare module 'socket.io' {
  interface Socket {
    userId?: string;
  }
}