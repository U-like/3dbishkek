import { db } from '@/lib/db'

async function main() {
  console.log('Seeding database...')

  // Create sample interests
  const interests = [
    { name: 'Музыка', category: 'hobby' },
    { name: 'Путешествия', category: 'hobby' },
    { name: 'Фотография', category: 'hobby' },
    { name: 'Книги', category: 'hobby' },
    { name: 'Кино', category: 'entertainment' },
    { name: 'Искусство', category: 'culture' },
    { name: 'Йога', category: 'sport' },
    { name: 'Здоровье', category: 'lifestyle' },
    { name: 'Природа', category: 'nature' },
    { name: 'Танцы', category: 'art' },
    { name: 'Театр', category: 'art' },
    { name: 'Мода', category: 'lifestyle' },
    { name: 'Кулинария', category: 'hobby' },
    { name: 'Садоводство', category: 'hobby' },
    { name: 'Спорт', category: 'sport' },
    { name: 'Технологии', category: 'interest' },
    { name: 'Наука', category: 'interest' },
    { name: 'Психология', category: 'interest' },
    { name: 'Бизнес', category: 'career' },
    { name: 'Образование', category: 'career' }
  ]

  for (const interest of interests) {
    await db.interest.upsert({
      where: { name: interest.name },
      update: {},
      create: interest
    })
  }

  // Create sample users
  const users = [
    {
      email: 'anna@example.com',
      name: 'Анна',
      bio: 'Люблю музыку и путешествия',
      gender: 'female',
      lookingFor: 'male',
      age: 25,
      location: 'Москва',
      interests: ['Музыка', 'Путешествия', 'Фотография']
    },
    {
      email: 'maria@example.com',
      name: 'Мария',
      bio: 'Ценю глубокие разговоры',
      gender: 'female',
      lookingFor: 'male',
      age: 28,
      location: 'Санкт-Петербург',
      interests: ['Книги', 'Кино', 'Искусство']
    },
    {
      email: 'elena@example.com',
      name: 'Елена',
      bio: 'Занимаюсь йогой и люблю природу',
      gender: 'female',
      lookingFor: 'male',
      age: 26,
      location: 'Казань',
      interests: ['Йога', 'Здоровье', 'Природа']
    },
    {
      email: 'olga@example.com',
      name: 'Ольга',
      bio: 'Танцы - моя страсть',
      gender: 'female',
      lookingFor: 'male',
      age: 24,
      location: 'Екатеринбург',
      interests: ['Танцы', 'Театр', 'Мода']
    },
    {
      email: 'natalia@example.com',
      name: 'Наталья',
      bio: 'Люблю готовить и путешествовать',
      gender: 'female',
      lookingFor: 'male',
      age: 30,
      location: 'Нижний Новгород',
      interests: ['Кулинария', 'Садоводство', 'Путешествия']
    },
    {
      email: 'alex@example.com',
      name: 'Александр',
      bio: 'Технологии и спорт',
      gender: 'male',
      lookingFor: 'female',
      age: 27,
      location: 'Москва',
      interests: ['Технологии', 'Спорт', 'Наука']
    },
    {
      email: 'dmitry@example.com',
      name: 'Дмитрий',
      bio: 'Предприниматель и путешественник',
      gender: 'male',
      lookingFor: 'female',
      age: 32,
      location: 'Санкт-Петербург',
      interests: ['Бизнес', 'Путешествия', 'Психология']
    },
    {
      email: 'ivan@example.com',
      name: 'Иван',
      bio: 'Учитель и музыкант',
      gender: 'male',
      lookingFor: 'female',
      age: 29,
      location: 'Новосибирск',
      interests: ['Музыка', 'Образование', 'Книги']
    }
  ]

  for (const userData of users) {
    const user = await db.user.create({
      data: {
        email: userData.email,
        name: userData.name,
        bio: userData.bio,
        gender: userData.gender,
        lookingFor: userData.lookingFor,
        age: userData.age,
        location: userData.location
      }
    })

    // Add interests to user
    for (const interestName of userData.interests) {
      const interest = await db.interest.findUnique({
        where: { name: interestName }
      })

      if (interest) {
        await db.userInterest.create({
          data: {
            userId: user.id,
            interestId: interest.id,
            level: Math.floor(Math.random() * 5) + 1 // Random level 1-5
          }
        })
      }
    }
  }

  // Create some matches
  const allUsers = await db.user.findMany()
  const maleUsers = allUsers.filter(u => u.gender === 'male')
  const femaleUsers = allUsers.filter(u => u.gender === 'female')

  for (let i = 0; i < Math.min(maleUsers.length, femaleUsers.length); i++) {
    const male = maleUsers[i]
    const female = femaleUsers[i]

    // Create match
    const match = await db.match.create({
      data: {
        senderId: male.id,
        receiverId: female.id,
        status: 'ACCEPTED',
        compatibility: Math.floor(Math.random() * 30) + 70 // 70-100%
      }
    })

    // Create chat for the match
    const chat = await db.chat.create({
      data: {
        matchId: match.id,
        participants: {
          connect: [
            { id: male.id },
            { id: female.id }
          ]
        }
      }
    })

    // Update match with chat ID
    await db.match.update({
      where: { id: match.id },
      data: { chatId: chat.id }
    })

    // Create some sample messages
    const messages = [
      'Привет! Как твои дела?',
      'Привет! Все отлично, спасибо. А у тебя?',
      'Тоже хорошо. Чем занимаешься?',
      'Работаю, увлекаюсь музыкой. А ты?',
      'Я люблю путешествовать и фотографировать.',
      'Круто! Я тоже люблю путешествовать.',
      'Может как-нибудь встретимся?',
      'Было бы здорово!'
    ]

    for (let j = 0; j < messages.length; j++) {
      await db.message.create({
        data: {
          chatId: chat.id,
          content: messages[j],
          senderId: j % 2 === 0 ? male.id : female.id
        }
      })
    }

    // Create chat activity
    await db.chatActivity.create({
      data: {
        chatId: chat.id,
        userId: male.id,
        weekNumber: 1,
        messageCount: 4,
        intensityScore: 65
      }
    })

    await db.chatActivity.create({
      data: {
        chatId: chat.id,
        userId: female.id,
        weekNumber: 1,
        messageCount: 4,
        intensityScore: 70
      }
    })
  }

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })