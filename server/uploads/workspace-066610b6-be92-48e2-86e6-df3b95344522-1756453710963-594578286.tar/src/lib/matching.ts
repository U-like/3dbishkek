import { User, UserInterest, Interest } from '@prisma/client'

export interface UserWithInterests extends User {
  interests: (UserInterest & {
    interest: Interest
  })[]
}

export interface CompatibilityScore {
  userId: string
  score: number
  breakdown: {
    interestOverlap: number
    interestLevel: number
    ageCompatibility: number
    locationProximity: number
    activityBonus: number
  }
}

/**
 * Calculate compatibility between two users
 */
export function calculateCompatibility(
  user1: UserWithInterests,
  user2: UserWithInterests
): CompatibilityScore {
  const breakdown = {
    interestOverlap: 0,
    interestLevel: 0,
    ageCompatibility: 0,
    locationProximity: 0,
    activityBonus: 0
  }

  // 1. Interest Overlap (40% of total score)
  const user1Interests = new Set(user1.interests.map(ui => ui.interest.name))
  const user2Interests = new Set(user2.interests.map(ui => ui.interest.name))
  
  const commonInterests = new Set([...user1Interests].filter(interest => 
    user2Interests.has(interest)
  ))
  
  const totalUniqueInterests = new Set([...user1Interests, ...user2Interests]).size
  breakdown.interestOverlap = totalUniqueInterests > 0 
    ? (commonInterests.size / totalUniqueInterests) * 40 
    : 0

  // 2. Interest Level Compatibility (20% of total score)
  let interestLevelScore = 0
  let commonInterestsCount = 0
  
  user1.interests.forEach(ui1 => {
    const ui2 = user2.interests.find(ui => ui.interest.name === ui1.interest.name)
    if (ui2) {
      commonInterestsCount++
      // Calculate level difference (closer levels = higher score)
      const levelDiff = Math.abs(ui1.level - ui2.level)
      const levelScore = Math.max(0, (5 - levelDiff) / 5) // 0-1 scale
      interestLevelScore += levelScore
    }
  })
  
  breakdown.interestLevel = commonInterestsCount > 0 
    ? (interestLevelScore / commonInterestsCount) * 20 
    : 0

  // 3. Age Compatibility (15% of total score)
  if (user1.age && user2.age) {
    const ageDiff = Math.abs(user1.age - user2.age)
    // Optimal age difference is 0-5 years
    breakdown.ageCompatibility = Math.max(0, (10 - ageDiff) / 10) * 15
  }

  // 4. Location Proximity (15% of total score)
  if (user1.location && user2.location) {
    // Simple location matching - same location gets full score
    breakdown.locationProximity = user1.location === user2.location ? 15 : 0
  }

  // 5. Activity Bonus (10% of total score)
  // This would be calculated based on chat activity, for now we'll use a random bonus
  breakdown.activityBonus = Math.random() * 10

  // Calculate total score
  const totalScore = Object.values(breakdown).reduce((sum, score) => sum + score, 0)

  return {
    userId: user2.id,
    score: Math.round(Math.min(100, Math.max(0, totalScore))),
    breakdown
  }
}

/**
 * Find compatible matches for a user
 */
export function findCompatibleMatches(
  targetUser: UserWithInterests,
  allUsers: UserWithInterests[],
  limit: number = 10
): Array<UserWithInterests & { compatibility: CompatibilityScore }> {
  // Filter out the target user and users of the same gender if lookingFor is specified
  const potentialMatches = allUsers.filter(user => {
    if (user.id === targetUser.id) return false
    
    // Basic gender filtering
    if (targetUser.lookingFor && targetUser.lookingFor !== 'all') {
      if (targetUser.lookingFor !== user.gender) return false
    }
    
    return true
  })

  // Calculate compatibility for each potential match
  const matchesWithScores = potentialMatches.map(user => ({
    ...user,
    compatibility: calculateCompatibility(targetUser, user)
  }))

  // Sort by compatibility score (highest first)
  matchesWithScores.sort((a, b) => b.compatibility.score - a.compatibility.score)

  // Return top matches
  return matchesWithScores.slice(0, limit)
}

/**
 * Sort users by various criteria
 */
export function sortUsers(
  users: UserWithInterests[],
  sortBy: 'compatibility' | 'activity' | 'newest' | 'online'
): UserWithInterests[] {
  const sortedUsers = [...users]

  switch (sortBy) {
    case 'compatibility':
      // This would require a target user to calculate compatibility
      // For now, we'll sort by number of interests as a proxy
      sortedUsers.sort((a, b) => b.interests.length - a.interests.length)
      break
    
    case 'activity':
      // Sort by last seen (most recent first)
      sortedUsers.sort((a, b) => {
        if (!a.lastSeen && !b.lastSeen) return 0
        if (!a.lastSeen) return 1
        if (!b.lastSeen) return -1
        return new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime()
      })
      break
    
    case 'newest':
      // Sort by creation date (newest first)
      sortedUsers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      break
    
    case 'online':
      // Online users first, then by last seen
      sortedUsers.sort((a, b) => {
        if (a.isOnline && !b.isOnline) return -1
        if (!a.isOnline && b.isOnline) return 1
        
        if (!a.lastSeen && !b.lastSeen) return 0
        if (!a.lastSeen) return 1
        if (!b.lastSeen) return -1
        return new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime()
      })
      break
    
    default:
      break
  }

  return sortedUsers
}

/**
 * Group users by interests
 */
export function groupUsersByInterests(users: UserWithInterests[]): Map<string, UserWithInterests[]> {
  const interestGroups = new Map<string, UserWithInterests[]>()

  users.forEach(user => {
    user.interests.forEach(userInterest => {
      const interestName = userInterest.interest.name
      
      if (!interestGroups.has(interestName)) {
        interestGroups.set(interestName, [])
      }
      
      interestGroups.get(interestName)!.push(user)
    })
  })

  return interestGroups
}

/**
 * Get interest suggestions based on user's current interests
 */
export function getInterestSuggestions(
  user: UserWithInterests,
  allInterests: Interest[],
  limit: number = 5
): Interest[] {
  const userInterestNames = new Set(user.interests.map(ui => ui.interest.name))
  
  // Filter out interests the user already has
  const availableInterests = allInterests.filter(interest => 
    !userInterestNames.has(interest.name)
  )

  // For now, return random interests
  // In a real app, this would use collaborative filtering or content-based filtering
  const shuffled = availableInterests.sort(() => 0.5 - Math.random())
  return shuffled.slice(0, limit)
}

/**
 * Calculate chat activity score
 */
export function calculateChatActivityScore(
  messageCount: number,
  avgMessageLength: number,
  responseTime: number,
  daysActive: number
): number {
  // Normalize different metrics
  const messageScore = Math.min(100, messageCount / 10) // 10 messages = 100%
  const lengthScore = Math.min(100, avgMessageLength / 50) // 50 chars = 100%
  const responseScore = Math.min(100, Math.max(0, (24 * 60 * 60 * 1000 - responseTime) / (24 * 60 * 60 * 1000))) // 24h response = 100%
  const consistencyScore = Math.min(100, daysActive / 7) // Active for 7 days = 100%

  // Weighted average
  return Math.round(
    messageScore * 0.3 +
    lengthScore * 0.2 +
    responseScore * 0.3 +
    consistencyScore * 0.2
  )
}