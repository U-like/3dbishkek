"use client"

import { useState, useEffect } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  Heart, 
  Star, 
  MapPin, 
  Calendar, 
  MessageCircle, 
  Eye, 
  EyeOff,
  Clock,
  TrendingUp,
  Activity
} from 'lucide-react'

interface User {
  id: string
  name: string
  avatar?: string
  avatarBlur: boolean
  isOnline: boolean
  lastSeen?: string
  compatibility: number
  interests: string[]
  bio?: string
  age?: number
  location?: string
  chatActivity?: {
    weekNumber: number
    messageCount: number
    intensityScore: number
  }[]
}

interface ProfileCardProps {
  user: User
  onChat?: () => void
  showActions?: boolean
  compact?: boolean
}

export default function ProfileCard({ 
  user, 
  onChat, 
  showActions = true, 
  compact = false 
}: ProfileCardProps) {
  const [isImageVisible, setIsImageVisible] = useState(!user.avatarBlur)
  const [showImage, setShowImage] = useState(false)

  // Calculate current week activity
  const currentWeekActivity = user.chatActivity?.find(
    activity => activity.weekNumber === getCurrentWeekNumber()
  )

  // Calculate total activity score
  const totalActivityScore = user.chatActivity?.reduce(
    (total, activity) => total + activity.intensityScore, 0
  ) || 0

  // Calculate blur reduction based on activity
  const blurReductionPercentage = Math.min(totalActivityScore / 400, 100) // Max 100% at 400 score

  useEffect(() => {
    // Check if image should be visible based on activity
    if (totalActivityScore >= 100) { // Threshold for image reveal
      setIsImageVisible(true)
    }
  }, [totalActivityScore])

  function getCurrentWeekNumber() {
    const now = new Date()
    const startOfYear = new Date(now.getFullYear(), 0, 1)
    const pastDaysOfYear = (now.getTime() - startOfYear.getTime()) / 86400000
    return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7)
  }

  const getCompatibilityColor = (compatibility: number) => {
    if (compatibility >= 80) return 'text-green-600'
    if (compatibility >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getCompatibilityBgColor = (compatibility: number) => {
    if (compatibility >= 80) return 'bg-green-100'
    if (compatibility >= 60) return 'bg-yellow-100'
    return 'bg-red-100'
  }

  const getActivityLevel = (score: number) => {
    if (score >= 80) return { level: 'Высокая', color: 'bg-green-500' }
    if (score >= 50) return { level: 'Средняя', color: 'bg-yellow-500' }
    return { level: 'Низкая', color: 'bg-red-500' }
  }

  if (compact) {
    return (
      <Card className="w-full hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar className="h-12 w-12">
                <AvatarImage 
                  src={user.avatar} 
                  className={isImageVisible ? '' : 'blur-sm'} 
                />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              {user.isOnline && (
                <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-medium truncate">{user.name}</h3>
                <div className="flex items-center gap-1">
                  <div className={`h-2 w-2 rounded-full ${getCompatibilityColor(user.compatibility).replace('text-', 'bg-')}`} />
                  <span className={`text-xs ${getCompatibilityColor(user.compatibility)}`}>
                    {user.compatibility}%
                  </span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground truncate">
                {user.age}, {user.location}
              </p>
              <div className="flex items-center gap-1 mt-1">
                <Activity className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  {getActivityLevel(totalActivityScore).level}
                </span>
              </div>
            </div>
            {showActions && (
              <Button size="sm" variant="outline" onClick={onChat}>
                <MessageCircle className="h-4 w-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="relative mx-auto w-32 h-32 mb-4">
          <Avatar className="h-full w-full">
            <AvatarImage 
              src={user.avatar} 
              className={isImageVisible ? '' : 'blur-sm transition-all duration-300'} 
              style={{
                filter: isImageVisible ? 'none' : `blur(${Math.max(0, 20 - (blurReductionPercentage / 5))}px)`
              }}
            />
            <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          
          {/* Online status indicator */}
          {user.isOnline && (
            <div className="absolute bottom-2 right-2 h-4 w-4 bg-green-500 rounded-full border-2 border-background" />
          )}
          
          {/* Image visibility toggle */}
          <Button
            size="sm"
            variant="secondary"
            className="absolute top-2 right-2 h-8 w-8 p-0"
            onClick={() => setShowImage(!showImage)}
          >
            {showImage ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
        </div>
        
        <CardTitle className="text-xl">{user.name}</CardTitle>
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{user.age} лет</span>
          <MapPin className="h-4 w-4 ml-2" />
          <span>{user.location}</span>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Compatibility Score */}
        <div className={`p-3 rounded-lg ${getCompatibilityBgColor(user.compatibility)}`}>
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium">Совместимость</span>
            <div className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              <span className={`font-bold ${getCompatibilityColor(user.compatibility)}`}>
                {user.compatibility}%
              </span>
            </div>
          </div>
          <Progress value={user.compatibility} className="h-2" />
        </div>

        {/* Bio */}
        {user.bio && (
          <div>
            <p className="text-sm text-muted-foreground">{user.bio}</p>
          </div>
        )}

        {/* Interests */}
        <div>
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <Star className="h-4 w-4" />
            Интересы
          </h4>
          <div className="flex flex-wrap gap-1">
            {user.interests.map((interest, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {interest}
              </Badge>
            ))}
          </div>
        </div>

        <Separator />

        {/* Activity Progress */}
        <div>
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Прогресс общения
          </h4>
          
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm">Открытие фото</span>
                <span className="text-sm font-medium">{Math.round(blurReductionPercentage)}%</span>
              </div>
              <Progress value={blurReductionPercentage} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">
                {isImageVisible 
                  ? 'Фото полностью открыто!' 
                  : `Общайтесь дальше, чтобы открыть фото (${Math.round(100 - blurReductionPercentage)}% осталось)`
                }
              </p>
            </div>

            {currentWeekActivity && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Активность на этой неделе
                  </span>
                  <span className="text-sm font-medium">{currentWeekActivity.messageCount} сообщений</span>
                </div>
                <Progress value={currentWeekActivity.intensityScore} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  Уровень: {getActivityLevel(currentWeekActivity.intensityScore).level}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-1">
            <div className={`h-2 w-2 rounded-full ${user.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
            {user.isOnline ? 'Онлайн' : user.lastSeen || 'Офлайн'}
          </span>
          <span className="text-muted-foreground">
            {user.interests.length} интересов
          </span>
        </div>

        {/* Actions */}
        {showActions && (
          <Button className="w-full" onClick={onChat}>
            <MessageCircle className="h-4 w-4 mr-2" />
            {user.chatActivity?.length ? 'Продолжить общение' : 'Начать общение'}
          </Button>
        )}
      </CardContent>
    </Card>
  )
}