"use client"

import { useState, useEffect } from 'react'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import { MessageSquare, Heart, Star, Clock, Users, Search } from 'lucide-react'
import EnhancedChat from '@/components/EnhancedChat'
import MobileDatingLayout from '@/components/MobileDatingLayout'

interface User {
  id: string
  name: string
  avatar?: string
  avatarBlur: boolean
  isOnline: boolean
  lastSeen?: string
  compatibility: number
  interests: string[]
  bio?: string
  age?: number
  location?: string
}

interface Chat {
  id: string
  name: string
  user: User
  lastMessage?: string
  lastMessageTime?: string
  unreadCount: number
}

interface Message {
  id: string
  content: string
  senderId: string
  createdAt: string
  read: boolean
  sender?: {
    name: string
    avatar?: string
    avatarBlur: boolean
  }
}

export default function DatingLayout() {
  const [isMobile, setIsMobile] = useState(false)
  const [activeChat, setActiveChat] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [currentUser] = useState({
    id: 'current-user',
    name: 'Вы'
  })

  // Check if mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Enhanced mock data for development
  const [existingChats, setExistingChats] = useState<Chat[]>([
    {
      id: '1',
      name: 'Анна',
      user: {
        id: '1',
        name: 'Анна',
        avatar: '/placeholder-avatar.jpg',
        avatarBlur: false,
        isOnline: true,
        compatibility: 85,
        interests: ['Музыка', 'Путешествия', 'Фотография'],
        bio: 'Люблю музыку и путешествия. Играю на гитаре и обожаю горы!',
        age: 25,
        location: 'Москва'
      },
      lastMessage: 'Привет! Как твои дела? Расскажи о себе',
      lastMessageTime: '10:30',
      unreadCount: 0
    },
    {
      id: '2',
      name: 'Мария',
      user: {
        id: '2',
        name: 'Мария',
        avatar: '/placeholder-avatar.jpg',
        avatarBlur: true,
        isOnline: false,
        lastSeen: '2 часа назад',
        compatibility: 72,
        interests: ['Книги', 'Кино', 'Искусство'],
        bio: 'Ценю глубокие разговоры и интеллектуальное общение',
        age: 28,
        location: 'Санкт-Петербург'
      },
      lastMessage: 'Было приятно пообщаться! Продолжим завтра?',
      lastMessageTime: 'Вчера',
      unreadCount: 1
    }
  ])

  const [potentialMatches, setPotentialMatches] = useState<User[]>([
    {
      id: '3',
      name: 'Елена',
      avatar: '/placeholder-avatar.jpg',
      avatarBlur: true,
      isOnline: true,
      compatibility: 92,
      interests: ['Йога', 'Здоровье', 'Природа'],
      bio: 'Занимаюсь йогой и люблю природу. Утренние пробежки - мой ритуал',
      age: 26,
      location: 'Казань'
    },
    {
      id: '4',
      name: 'Ольга',
      avatar: '/placeholder-avatar.jpg',
      avatarBlur: true,
      isOnline: false,
      lastSeen: '5 часов назад',
      compatibility: 78,
      interests: ['Танцы', 'Театр', 'Мода'],
      bio: 'Танцы - моя страсть. Участвую в танцевальных конкурсах',
      age: 24,
      location: 'Екатеринбург'
    },
    {
      id: '5',
      name: 'Наталья',
      avatar: '/placeholder-avatar.jpg',
      avatarBlur: true,
      isOnline: true,
      compatibility: 88,
      interests: ['Кулинария', 'Садоводство', 'Путешествия'],
      bio: 'Люблю готовить и путешествовать. Мечтаю посетить Италию',
      age: 30,
      location: 'Нижний Новгород'
    }
  ])

  // Sample messages for each chat
  const chatMessages: Record<string, Message[]> = {
    '1': [
      {
        id: '1',
        content: 'Привет! Рад(а) знакомству с тобой 😊',
        senderId: '1',
        createdAt: '2024-01-15T10:25:00',
        read: true,
        sender: {
          name: 'Анна',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: false
        }
      },
      {
        id: '2',
        content: 'Привет! И я очень рад(а)! Ты интересный человек',
        senderId: 'current-user',
        createdAt: '2024-01-15T10:26:00',
        read: true
      },
      {
        id: '3',
        content: 'Спасибо! Расскажи, чем увлекаешься в жизни?',
        senderId: '1',
        createdAt: '2024-01-15T10:28:00',
        read: true,
        sender: {
          name: 'Анна',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: false
        }
      },
      {
        id: '4',
        content: 'Я люблю музыку, особенно живую. А еще увлекаюсь фотографией и путешествиями',
        senderId: '1',
        createdAt: '2024-01-15T10:29:00',
        read: true,
        sender: {
          name: 'Анна',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: false
        }
      },
      {
        id: '5',
        content: 'Круто! Я тоже обожаю путешествия. Где ты уже был(а)?',
        senderId: 'current-user',
        createdAt: '2024-01-15T10:30:00',
        read: false
      }
    ],
    '2': [
      {
        id: '1',
        content: 'Здравствуйте! Нравится ваш профиль',
        senderId: '2',
        createdAt: '2024-01-14T18:20:00',
        read: true,
        sender: {
          name: 'Мария',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: true
        }
      },
      {
        id: '2',
        content: 'Добрый вечер! Спасибо, приятно слышать',
        senderId: 'current-user',
        createdAt: '2024-01-14T18:22:00',
        read: true
      },
      {
        id: '3',
        content: 'Чем занимаешься в свободное время?',
        senderId: '2',
        createdAt: '2024-01-14T18:25:00',
        read: true,
        sender: {
          name: 'Мария',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: true
        }
      },
      {
        id: '4',
        content: 'Люблю читать книги и смотреть артхаусное кино. А ты?',
        senderId: 'current-user',
        createdAt: '2024-01-14T18:30:00',
        read: true
      },
      {
        id: '5',
        content: 'Было приятно пообщаться! Продолжим завтра?',
        senderId: '2',
        createdAt: '2024-01-14T18:35:00',
        read: false,
        sender: {
          name: 'Мария',
          avatar: '/placeholder-avatar.jpg',
          avatarBlur: true
        }
      }
    ]
  }

  // Load messages when chat is selected
  useEffect(() => {
    if (activeChat && chatMessages[activeChat]) {
      setMessages(chatMessages[activeChat])
    } else {
      setMessages([])
    }
  }, [activeChat])

  const filteredChats = existingChats.filter(chat =>
    chat.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const filteredMatches = potentialMatches.filter(match =>
    match.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const sendMessage = (content: string) => {
    if (content.trim() && activeChat) {
      const message: Message = {
        id: Date.now().toString(),
        content,
        senderId: 'current-user',
        createdAt: new Date().toISOString(),
        read: false
      }
      
      setMessages(prev => [...prev, message])
      
      // Update chat last message
      setExistingChats(prev => prev.map(chat => 
        chat.id === activeChat 
          ? { ...chat, lastMessage: content, lastMessageTime: 'Только что' }
          : chat
      ))
    }
  }

  const startChat = (user: User) => {
    const newChat: Chat = {
      id: Date.now().toString(),
      name: user.name,
      user,
      lastMessage: '',
      unreadCount: 0
    }
    setExistingChats([newChat, ...existingChats])
    setPotentialMatches(potentialMatches.filter(match => match.id !== user.id))
    setActiveChat(newChat.id)
    setMessages([])
  }

  const getCompatibilityColor = (compatibility: number) => {
    if (compatibility >= 80) return 'bg-green-500'
    if (compatibility >= 60) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const getActiveChatData = () => {
    return existingChats.find(chat => chat.id === activeChat)
  }

  // Return mobile layout if on mobile device
  if (isMobile) {
    return <MobileDatingLayout />
  }

  // Desktop layout
  return (
    <div className="h-full w-full bg-gradient-to-br from-pink-50 via-white to-purple-50">
      <ResizablePanelGroup direction="horizontal" className="h-full w-full">
        {/* Left Panel - Existing Chats */}
        <ResizablePanel defaultSize={25} minSize={20}>
          <Card className="h-full w-full rounded-none border-r bg-white/80">
            <CardHeader className="pb-3 bg-gradient-to-r from-pink-50 to-purple-50">
              <CardTitle className="flex items-center gap-2 text-lg">
                <MessageSquare className="h-5 w-5 text-pink-600" />
                <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent font-bold">
                  Мои чаты
                </span>
              </CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Поиск чатов..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/80"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-120px)] w-full">
                {filteredChats.map((chat) => (
                  <div
                    key={chat.id}
                    className={`p-4 hover:bg-gradient-to-r hover:from-pink-50 hover:to-purple-50 cursor-pointer border-b transition-all duration-200 ${
                      activeChat === chat.id ? 'bg-gradient-to-r from-pink-50 to-purple-50 border-l-4 border-l-pink-500' : ''
                    }`}
                    onClick={() => setActiveChat(chat.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Avatar className="h-12 w-12 ring-2 ring-white shadow-sm">
                          <AvatarImage 
                            src={chat.user.avatar} 
                            className={chat.user.avatarBlur ? 'blur-sm transition-all duration-300' : ''} 
                          />
                          <AvatarFallback className="bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold">
                            {chat.user.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        {chat.user.isOnline && (
                          <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white shadow-sm" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-gray-800 truncate">{chat.user.name}</h3>
                          <div className="flex items-center gap-1">
                            <div className={`h-2 w-2 rounded-full ${getCompatibilityColor(chat.user.compatibility)}`} />
                            <span className="text-xs text-muted-foreground font-medium">{chat.user.compatibility}%</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-muted-foreground">{chat.lastMessageTime}</span>
                          {chat.unreadCount > 0 && (
                            <Badge variant="destructive" className="h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-gradient-to-r from-pink-500 to-purple-500">
                              {chat.unreadCount}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Center Panel - Chat */}
        <ResizablePanel defaultSize={50} minSize={30}>
          {activeChat && getActiveChatData() ? (
            <Card className="h-full w-full rounded-none bg-white/80 overflow-hidden">
              <EnhancedChat
                chat={getActiveChatData()!}
                messages={messages}
                onSendMessage={sendMessage}
                currentUser={currentUser}
              />
            </Card>
          ) : (
            <Card className="h-full w-full rounded-none bg-white/80">
              <div className="flex items-center justify-center h-full w-full text-center">
                <div className="max-w-md">
                  <div className="w-24 h-24 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <MessageSquare className="h-12 w-12 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-4">
                    Добро пожаловать в чат
                  </h2>
                  <p className="text-gray-600 mb-2">
                    Выберите существующий чат или начните новое знакомство
                  </p>
                  <p className="text-sm text-gray-500">
                    Чем интенсивнее общение, тем быстрее откроется фото вашего собеседника
                  </p>
                </div>
              </div>
            </Card>
          )}
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Right Panel - Potential Matches */}
        <ResizablePanel defaultSize={25} minSize={20}>
          <Card className="h-full w-full rounded-none border-l bg-white/80">
            <CardHeader className="pb-3 bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="h-5 w-5 text-purple-600" />
                <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-bold">
                  Новые знакомства
                </span>
              </CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Поиск людей..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/80"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-120px)] w-full">
                {filteredMatches.map((match) => (
                  <div key={match.id} className="p-4 border-b hover:bg-gradient-to-r hover:from-purple-50 hover:to-pink-50 transition-all duration-200">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <Avatar className="h-12 w-12 ring-2 ring-white shadow-sm">
                          <AvatarImage 
                            src={match.avatar} 
                            className={match.avatarBlur ? 'blur-sm transition-all duration-300' : ''} 
                          />
                          <AvatarFallback className="bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold">
                            {match.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        {match.isOnline && (
                          <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white shadow-sm" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-gray-800 truncate">{match.name}</h3>
                          <div className="flex items-center gap-1">
                            <div className={`h-2 w-2 rounded-full ${getCompatibilityColor(match.compatibility)}`} />
                            <span className="text-xs text-muted-foreground font-medium">{match.compatibility}%</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {match.age}, {match.location}
                        </p>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {match.bio}
                    </p>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {match.interests.slice(0, 3).map((interest, index) => (
                        <Badge key={index} variant="secondary" className="text-xs bg-purple-100 text-purple-700">
                          {interest}
                        </Badge>
                      ))}
                      {match.interests.length > 3 && (
                        <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-700">
                          +{match.interests.length - 3}
                        </Badge>
                      )}
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                      onClick={() => startChat(match)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Начать общение
                    </Button>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  )
}