"use client"

import { useState, useEffect } from 'react'
import DatingLayout from '@/components/DatingLayout'
import AuthForm from '@/components/auth/AuthForm'
import { useSocket } from '@/hooks/useSocket'

interface User {
  id: string
  email: string
  name: string
  avatar?: string
  avatarBlur: boolean
  isOnline: boolean
  compatibility: number
  interests: string[]
  bio?: string
  age?: number
  location?: string
  gender?: string
  lookingFor?: string
}

export default function DatingApp() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  
  const { isConnected, joinChat, sendMessage, onNewMessage } = useSocket({
    userId: currentUser?.id,
    autoConnect: !!currentUser?.id
  })

  useEffect(() => {
    // Check if user is already logged in (from localStorage or cookie)
    const savedUser = localStorage.getItem('datingAppUser')
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser)
        setCurrentUser(user)
      } catch (error) {
        console.error('Error parsing saved user:', error)
        localStorage.removeItem('datingAppUser')
      }
    }
    setIsLoading(false)
  }, [])

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user)
    localStorage.setItem('datingAppUser', JSON.stringify(user))
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem('datingAppUser')
  }

  // Set up socket event listeners
  useEffect(() => {
    if (currentUser && isConnected) {
      onNewMessage((message) => {
        console.log('New message received:', message)
        // Handle new message - could update state, show notification, etc.
      })
    }
  }, [currentUser, isConnected, onNewMessage])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-pink-500"></div>
      </div>
    )
  }

  if (!currentUser) {
    return <AuthForm onAuthSuccess={handleAuthSuccess} />
  }

  return (
    <div className="h-screen flex flex-col">
      {/* Header - Fixed height */}
      <header className="bg-white border-b px-4 py-3 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg">
            <span className="text-white font-bold text-lg">♥</span>
          </div>
          <h1 className="text-xl font-bold">Знакомства без свайпов</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-muted-foreground">
              {isConnected ? 'Онлайн' : 'Офлайн'}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
              {currentUser.name.charAt(0)}
            </div>
            <span className="font-medium">{currentUser.name}</span>
          </div>
          
          <button
            onClick={handleLogout}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Выйти
          </button>
        </div>
      </header>

      {/* Main Content - Flexible height */}
      <main className="flex-1 overflow-hidden min-h-0">
        <DatingLayout />
      </main>
    </div>
  )
}