"use client"

import { useState, useEffect, useRef } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { 
  MessageSquare, 
  Send, 
  Heart, 
  Star, 
  Clock, 
  Users, 
  Search,
  Paperclip,
  Smile,
  MoreVertical,
  Phone,
  Video,
  Check,
  CheckCheck,
  ChevronUp,
  ChevronDown
} from 'lucide-react'
import { useSocket } from '@/hooks/useSocket'

interface User {
  id: string
  name: string
  avatar?: string
  avatarBlur: boolean
  isOnline: boolean
  lastSeen?: string
  compatibility: number
  interests: string[]
  bio?: string
  age?: number
  location?: string
}

interface Message {
  id: string
  content: string
  senderId: string
  createdAt: string
  read: boolean
  sender?: {
    name: string
    avatar?: string
    avatarBlur: boolean
  }
}

interface ChatProps {
  chat: {
    id: string
    name: string
    user: User
    lastMessage?: string
    lastMessageTime?: string
    unreadCount: number
  }
  messages: Message[]
  onSendMessage: (content: string) => void
  onMessageRead?: (messageId: string) => void
  currentUser?: {
    id: string
    name: string
  }
}

export default function EnhancedChat({ 
  chat, 
  messages, 
  onSendMessage, 
  onMessageRead,
  currentUser 
}: ChatProps) {
  const [newMessage, setNewMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [showProfile, setShowProfile] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  
  const { sendMessage: sendSocketMessage, startTyping, stopTyping } = useSocket({
    userId: currentUser?.id,
    autoConnect: !!currentUser?.id
  })

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, 100)
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage)
      sendSocketMessage({
        chatId: chat.id,
        content: newMessage,
        senderId: currentUser?.id || 'current-user'
      })
      setNewMessage('')
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setNewMessage(value)
    
    // Handle typing indicators
    if (value.trim()) {
      if (!isTyping) {
        setIsTyping(true)
        startTyping(chat.id, currentUser?.id || 'current-user')
      }
    } else {
      if (isTyping) {
        setIsTyping(false)
        stopTyping(chat.id, currentUser?.id || 'current-user')
      }
    }
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.abs(now.getTime() - date.getTime()) / (1000 * 60 * 60)
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    } else {
      return date.toLocaleDateString([], { day: '2-digit', month: '2-digit' })
    }
  }

  const getCompatibilityColor = (compatibility: number) => {
    if (compatibility >= 80) return 'bg-green-500'
    if (compatibility >= 60) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  return (
    <div className="h-full flex flex-col">
      {/* Chat Header - Fixed */}
      <div className="flex-shrink-0">
        <CardHeader className="pb-3 border-b bg-gradient-to-r from-pink-50 to-purple-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar className="h-12 w-12 ring-2 ring-white shadow-lg">
                  <AvatarImage 
                    src={chat.user.avatar} 
                    className={chat.user.avatarBlur ? 'blur-sm transition-all duration-300' : ''} 
                  />
                  <AvatarFallback className="bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold">
                    {chat.user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                {chat.user.isOnline && (
                  <div className="absolute bottom-0 right-0 h-4 w-4 bg-green-500 rounded-full border-2 border-white shadow-sm" />
                )}
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-800">{chat.user.name}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <div className={`h-2 w-2 rounded-full ${getCompatibilityColor(chat.user.compatibility)}`} />
                    {chat.user.compatibility}% совместимость
                  </span>
                  <span>•</span>
                  <span>{chat.user.age} лет</span>
                  <span>•</span>
                  <span>{chat.user.location}</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {chat.user.isOnline ? 'Онлайн' : chat.user.lastSeen || 'Был(а) недавно'}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="flex items-center gap-1 bg-white/80">
                <Star className="h-3 w-3" />
                {chat.user.interests.length} интересов
              </Badge>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Phone className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Video className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Profile Toggle */}
          <div className="mt-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowProfile(!showProfile)}
              className="flex items-center gap-2 text-xs"
            >
              {showProfile ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              {showProfile ? 'Скрыть профиль' : 'Показать профиль'}
            </Button>
          </div>
        </CardHeader>

        {/* Extended Profile Info - Collapsible */}
        {showProfile && (
          <CardContent className="pb-3 bg-gradient-to-r from-pink-50 to-purple-50 border-b">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-semibold text-gray-700 mb-2">О себе</h4>
                <p className="text-gray-600 text-xs leading-relaxed">{chat.user.bio}</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-700 mb-2">Интересы</h4>
                <div className="flex flex-wrap gap-1">
                  {chat.user.interests.slice(0, 6).map((interest, index) => (
                    <Badge key={index} variant="secondary" className="text-xs bg-white/80">
                      {interest}
                    </Badge>
                  ))}
                  {chat.user.interests.length > 6 && (
                    <Badge variant="secondary" className="text-xs bg-white/80">
                      +{chat.user.interests.length - 6}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </div>

      {/* Messages Area - Scrollable */}
      <CardContent className="flex-1 p-0 min-h-0">
        <ScrollArea 
          ref={scrollAreaRef}
          className="h-full w-full p-4 bg-gradient-to-b from-white to-pink-50/20"
        >
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-center min-h-[400px]">
              <div className="max-w-sm">
                <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  Начните общение!
                </h3>
                <p className="text-gray-600 mb-1">
                  Чем интенсивнее общение, тем быстрее откроется фото
                </p>
                <p className="text-sm text-gray-500">
                  Будьте искренни и проявите интерес к собеседнику
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4 pb-4">
              {messages.map((message) => {
                const isCurrentUser = message.senderId === currentUser?.id
                
                return (
                  <div
                    key={message.id}
                    className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex gap-3 max-w-[80%] ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
                      {!isCurrentUser && (
                        <Avatar className="h-8 w-8 flex-shrink-0 mt-1">
                          <AvatarImage 
                            src={message.sender?.avatar} 
                            className={message.sender?.avatarBlur ? 'blur-sm' : ''} 
                          />
                          <AvatarFallback className="text-xs">
                            {message.sender?.name?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                      )}
                      
                      <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                        <div
                          className={`px-4 py-3 rounded-2xl shadow-sm ${
                            isCurrentUser
                              ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-br-none'
                              : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
                          }`}
                        >
                          <p className="text-sm leading-relaxed">{message.content}</p>
                          <div className={`flex items-center gap-1 mt-2 text-xs ${
                            isCurrentUser ? 'text-pink-100' : 'text-gray-500'
                          }`}>
                            <span>{formatTime(message.createdAt)}</span>
                            {isCurrentUser && (
                              <span>
                                {message.read ? (
                                  <CheckCheck className="h-3 w-3" />
                                ) : (
                                  <Check className="h-3 w-3" />
                                )}
                              </span>
                            )}
                          </div>
                        </div>
                        
                        {!isCurrentUser && (
                          <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                            <span>{message.sender?.name}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>
      </CardContent>

      {/* Message Input - Fixed */}
      <div className="flex-shrink-0">
        <div className="p-4 border-t bg-white/80 backdrop-blur-sm">
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" className="h-10 w-10 p-0">
              <Paperclip className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" className="h-10 w-10 p-0">
              <Smile className="h-4 w-4" />
            </Button>
            
            <div className="flex-1 relative">
              <textarea
                placeholder="Напишите сообщение..."
                value={newMessage}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-gray-50"
                rows={1}
                style={{ minHeight: '44px', maxHeight: '120px' }}
              />
              <Button
                size="sm"
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
                className="absolute right-1 bottom-1 h-8 w-8 p-0 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Chat Progress Indicator */}
          <div className="mt-3 p-2 bg-gradient-to-r from-pink-100 to-purple-100 rounded-lg">
            <div className="flex items-center justify-between text-xs text-gray-700">
              <span className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                Прогресс общения
              </span>
              <span>45% к открытию фото</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
              <div className="bg-gradient-to-r from-pink-500 to-purple-500 h-1.5 rounded-full transition-all duration-300" style={{ width: '45%' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}