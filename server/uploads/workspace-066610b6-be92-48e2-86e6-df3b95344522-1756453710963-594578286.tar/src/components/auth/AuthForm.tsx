"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Heart, User, Mail, Lock, Calendar, MapPin } from 'lucide-react'

interface AuthFormProps {
  onAuthSuccess: (user: any) => void
}

export default function AuthForm({ onAuthSuccess }: AuthFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  })
  const [registerData, setRegisterData] = useState({
    email: '',
    password: '',
    name: '',
    age: '',
    gender: '',
    lookingFor: '',
    location: '',
    bio: '',
    interests: [] as string[]
  })

  const [newInterest, setNewInterest] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      // Mock login - in real app, this would call your auth API
      const mockUser = {
        id: 'user_' + Date.now(),
        email: loginData.email,
        name: 'Пользователь',
        avatar: '/placeholder-avatar.jpg',
        avatarBlur: true,
        isOnline: true,
        compatibility: 85,
        interests: ['Музыка', 'Путешествия'],
        bio: 'Добро пожаловать в приложение!',
        age: 25,
        location: 'Москва'
      }
      
      setTimeout(() => {
        onAuthSuccess(mockUser)
        setIsLoading(false)
      }, 1000)
    } catch (error) {
      console.error('Login error:', error)
      setIsLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      // Mock registration - in real app, this would call your registration API
      const mockUser = {
        id: 'user_' + Date.now(),
        email: registerData.email,
        name: registerData.name,
        avatar: '/placeholder-avatar.jpg',
        avatarBlur: true,
        isOnline: true,
        compatibility: 75,
        interests: registerData.interests,
        bio: registerData.bio,
        age: parseInt(registerData.age),
        location: registerData.location,
        gender: registerData.gender,
        lookingFor: registerData.lookingFor
      }
      
      setTimeout(() => {
        onAuthSuccess(mockUser)
        setIsLoading(false)
      }, 1000)
    } catch (error) {
      console.error('Registration error:', error)
      setIsLoading(false)
    }
  }

  const addInterest = () => {
    if (newInterest.trim() && !registerData.interests.includes(newInterest.trim())) {
      setRegisterData(prev => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()]
      }))
      setNewInterest('')
    }
  }

  const removeInterest = (interest: string) => {
    setRegisterData(prev => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }))
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full">
              <Heart className="h-8 w-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Добро пожаловать</CardTitle>
          <CardDescription>
            Найдите свою любовь без свайпов
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Вход</TabsTrigger>
              <TabsTrigger value="register">Регистрация</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login" className="space-y-4">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="your@email.com"
                      className="pl-10"
                      value={loginData.email}
                      onChange={(e) => setLoginData(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="login-password">Пароль</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="••••••••"
                      className="pl-10"
                      value={loginData.password}
                      onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Вход...' : 'Войти'}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register" className="space-y-4">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="register-name">Имя</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="register-name"
                      type="text"
                      placeholder="Ваше имя"
                      className="pl-10"
                      value={registerData.name}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="register-email"
                      type="email"
                      placeholder="your@email.com"
                      className="pl-10"
                      value={registerData.email}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-password">Пароль</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="register-password"
                      type="password"
                      placeholder="••••••••"
                      className="pl-10"
                      value={registerData.password}
                      onChange={(e) => setRegisterData(prev => ({ ...prev, password: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label htmlFor="register-age">Возраст</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        id="register-age"
                        type="number"
                        placeholder="25"
                        className="pl-10"
                        value={registerData.age}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, age: e.target.value }))}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-gender">Пол</Label>
                    <Select 
                      value={registerData.gender} 
                      onValueChange={(value) => setRegisterData(prev => ({ ...prev, gender: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Мужской</SelectItem>
                        <SelectItem value="female">Женский</SelectItem>
                        <SelectItem value="other">Другой</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label htmlFor="register-looking">Ищу</Label>
                    <Select 
                      value={registerData.lookingFor} 
                      onValueChange={(value) => setRegisterData(prev => ({ ...prev, lookingFor: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Мужчин</SelectItem>
                        <SelectItem value="female">Женщин</SelectItem>
                        <SelectItem value="all">Всех</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-location">Город</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        id="register-location"
                        type="text"
                        placeholder="Москва"
                        className="pl-10"
                        value={registerData.location}
                        onChange={(e) => setRegisterData(prev => ({ ...prev, location: e.target.value }))}
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-bio">О себе</Label>
                  <textarea
                    id="register-bio"
                    placeholder="Расскажите о себе..."
                    className="w-full p-3 border border-input rounded-md min-h-[80px] resize-none"
                    value={registerData.bio}
                    onChange={(e) => setRegisterData(prev => ({ ...prev, bio: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Интересы</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Добавить интерес"
                      value={newInterest}
                      onChange={(e) => setNewInterest(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addInterest())}
                    />
                    <Button type="button" onClick={addInterest} size="sm">
                      +
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {registerData.interests.map((interest, index) => (
                      <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeInterest(interest)}>
                        {interest} ×
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Регистрация...' : 'Зарегистрироваться'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}