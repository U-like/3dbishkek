"use client"

import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'

interface UseSocketOptions {
  userId?: string
  autoConnect?: boolean
}

interface ChatMessage {
  id: string
  chatId: string
  content: string
  senderId: string
  timestamp: string
}

interface ChatActivity {
  chatId: string
  userId: string
  messageCount: number
  intensityScore: number
}

interface TypingIndicator {
  userId: string
  chatId: string
}

export function useSocket(options: UseSocketOptions = {}) {
  const { userId, autoConnect = true } = options
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [onlineUsers, setOnlineUsers] = useState<string[]>([])
  const [typingUsers, setTypingUsers] = useState<Map<string, TypingIndicator>>(new Map())

  // Initialize socket connection
  useEffect(() => {
    if (typeof window === 'undefined') return

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3001', {
      autoConnect,
      transports: ['websocket', 'polling']
    })

    socketRef.current = socket

    // Connection events
    socket.on('connect', () => {
      setIsConnected(true)
      console.log('Socket connected')
      
      // Join with user ID if provided
      if (userId) {
        socket.emit('user:join', { userId })
      }
    })

    socket.on('disconnect', () => {
      setIsConnected(false)
      console.log('Socket disconnected')
    })

    // User online/offline events
    socket.on('user:online', (data: { userId: string }) => {
      setOnlineUsers(prev => [...prev, data.userId])
    })

    socket.on('user:offline', (data: { userId: string }) => {
      setOnlineUsers(prev => prev.filter(id => id !== data.userId))
    })

    // Get online users
    socket.on('users:online', (users: string[]) => {
      setOnlineUsers(users)
    })

    // Typing indicators
    socket.on('typing:start', (data: TypingIndicator) => {
      setTypingUsers(prev => new Map(prev).set(data.userId, data))
    })

    socket.on('typing:stop', (data: TypingIndicator) => {
      setTypingUsers(prev => {
        const newMap = new Map(prev)
        newMap.delete(data.userId)
        return newMap
      })
    })

    return () => {
      socket.disconnect()
      socketRef.current = null
    }
  }, [userId, autoConnect])

  // Update user ID when it changes
  useEffect(() => {
    if (socketRef.current && userId && isConnected) {
      socketRef.current.emit('user:join', { userId })
    }
  }, [userId, isConnected])

  // Chat room management
  const joinChat = (chatId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('chat:join', { chatId })
    }
  }

  const leaveChat = (chatId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('chat:leave', { chatId })
    }
  }

  // Message handling
  const sendMessage = (message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('message:send', message)
    }
  }

  const markMessageAsRead = (messageId: string, userId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('message:read', { messageId, userId })
    }
  }

  // Typing indicators
  const startTyping = (chatId: string, userId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('typing:start', { chatId, userId })
    }
  }

  const stopTyping = (chatId: string, userId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('typing:stop', { chatId, userId })
    }
  }

  // Match handling
  const sendMatchRequest = (senderId: string, receiverId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('match:request', { senderId, receiverId })
    }
  }

  const sendMatchResponse = (senderId: string, receiverId: string, accepted: boolean, chatId?: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('match:response', { senderId, receiverId, accepted, chatId })
    }
  }

  // Event listeners
  const onNewMessage = (callback: (message: ChatMessage) => void) => {
    if (socketRef.current) {
      socketRef.current.on('message:new', callback)
    }
  }

  const onChatActivity = (callback: (activity: ChatActivity) => void) => {
    if (socketRef.current) {
      socketRef.current.on('chat:activity', callback)
    }
  }

  const onMatchRequest = (callback: (data: { senderId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('match:request', callback)
    }
  }

  const onMatchResponse = (callback: (data: { 
    receiverId: string; 
    accepted: boolean; 
    chatId?: string 
  }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('match:response', callback)
    }
  }

  const onMessageRead = (callback: (data: { messageId: string; userId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('message:read', callback)
    }
  }

  const onError = (callback: (error: { message: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('error', callback)
    }
  }

  // Remove event listeners
  const offNewMessage = (callback: (message: ChatMessage) => void) => {
    if (socketRef.current) {
      socketRef.current.off('message:new', callback)
    }
  }

  const offChatActivity = (callback: (activity: ChatActivity) => void) => {
    if (socketRef.current) {
      socketRef.current.off('chat:activity', callback)
    }
  }

  const offMatchRequest = (callback: (data: { senderId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('match:request', callback)
    }
  }

  const offMatchResponse = (callback: (data: { 
    receiverId: string; 
    accepted: boolean; 
    chatId?: string 
  }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('match:response', callback)
    }
  }

  const offMessageRead = (callback: (data: { messageId: string; userId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('message:read', callback)
    }
  }

  const offError = (callback: (error: { message: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('error', callback)
    }
  }

  return {
    isConnected,
    onlineUsers,
    typingUsers,
    socket: socketRef.current,
    joinChat,
    leaveChat,
    sendMessage,
    markMessageAsRead,
    startTyping,
    stopTyping,
    sendMatchRequest,
    sendMatchResponse,
    onNewMessage,
    onChatActivity,
    onMatchRequest,
    onMatchResponse,
    onMessageRead,
    onError,
    offNewMessage,
    offChatActivity,
    offMatchRequest,
    offMatchResponse,
    offMessageRead,
    offError
  }
}